def cek_kodepos(kodepos):
    pairs = 0
    for i in range(len(digits) - 2)
        if digits[i] == digits[i+2] and digits